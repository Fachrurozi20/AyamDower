package com.example.myapplication

class DataClass {

    var dataNama: String? = null
    var dataDesc: String? = null
    var dataNumber: String? = null
    var dataImage: String? = null

    constructor(dataNama:String?, dataDesc: String?, dataNumber: String?, dataImage: String?){
        this.dataNama=dataNama
        this.dataDesc=dataDesc
        this.dataNumber=dataNumber
        this.dataImage=dataImage
    }
}